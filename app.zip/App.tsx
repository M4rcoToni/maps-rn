import { Home } from './src/Home/Home';

export default function App() {
  return (
    <Home />
  );
}

